#!/bin/bash
set -e

AGENT_PLIST="com.example.corpnetwork.plist"
AGENT_DEST="$HOME/Library/LaunchAgents/$AGENT_PLIST"
LOG_FILE="$HOME/Library/Logs/corp_network_check.log"

echo "Uninstalling Corp Network Detector..."

if launchctl list | grep -q "com.example.corpnetwork"; then
    launchctl stop com.example.corpnetwork || true
    launchctl unload "$AGENT_DEST" || true
fi

if [ -f "$AGENT_DEST" ]; then
    rm -f "$AGENT_DEST"
    echo "Removed LaunchAgent: $AGENT_DEST"
fi

if [ -f "$LOG_FILE" ]; then
    rm -f "$LOG_FILE"
    echo "Removed log file: $LOG_FILE"
fi

echo "✅ Uninstallation complete."
