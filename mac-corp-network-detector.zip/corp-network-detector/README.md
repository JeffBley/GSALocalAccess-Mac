# Corp Network Detector (macOS LaunchAgent)

This tool detects when your Mac joins or leaves the corporate network by 
checking if a private domain can be resolved. It then updates a preference 
key to enable or disable Private Access.

---

## Features
- Detects network change events.
- Checks resolution of: `private.edgediagnostic.globalsecureaccess.microsoft.com`
- Updates:
  - Inside corp network:
    `defaults write com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 1`
  - Outside corp network:
    `defaults write com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 0`
- Logs results to:
  `~/Library/Logs/corp_network_check.log`

---

## Installation

```bash
cd ~/corp-network-detector
./install.sh
