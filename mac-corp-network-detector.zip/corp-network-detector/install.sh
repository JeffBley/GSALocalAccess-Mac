#!/bin/bash
set -e

AGENT_LABEL="com.example.corpnetwork"
AGENT_PLIST="$AGENT_LABEL.plist"
AGENT_DEST="$HOME/Library/LaunchAgents/$AGENT_PLIST"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "🔄 Installing Corp Network Detector..."

USERNAME=$(whoami)
SCRIPT_PATH="$SCRIPT_DIR/corp_network_check.sh"

# Stop and unload old agent if it exists
if launchctl list | grep -q "$AGENT_LABEL"; then
    echo "Stopping existing agent..."
    launchctl stop "$AGENT_LABEL" || true
    launchctl unload "$AGENT_DEST" || true
fi

# Remove old plist if it exists
if [ -f "$AGENT_DEST" ]; then
    echo "Removing old plist..."
    rm -f "$AGENT_DEST"
fi

# Replace placeholders in plist with actual username and script path
sed -e "s|YOUR_USERNAME|$USERNAME|g" \
    -e "s|/Users/$USERNAME/corp-network-detector/corp_network_check.sh|$SCRIPT_PATH|g" \
    "$SCRIPT_DIR/$AGENT_PLIST" > "$AGENT_DEST"

# Load new agent
launchctl load "$AGENT_DEST"
launchctl start "$AGENT_LABEL"

echo "✅ Installation complete."
echo "Logs available at: $HOME/Library/Logs/corp_network_check.log"
