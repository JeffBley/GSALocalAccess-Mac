#!/bin/bash

CORP_DOMAIN="private.edgediagnostic.globalsecureaccess.microsoft.com"
LOG_FILE="$HOME/Library/Logs/corp_network_check.log"

check_corp_network() {
    if nslookup "$CORP_DOMAIN" >/dev/null 2>&1; then
        echo "$(date): ✅ Inside corp network (resolved $CORP_DOMAIN)" >> "$LOG_FILE"
        defaults write com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 1
    else
        echo "$(date): ❌ Outside corp network (failed to resolve $CORP_DOMAIN)" >> "$LOG_FILE"
        defaults write com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 0
    fi
}

# Loop forever, checking every 10 seconds
while true; do
    check_corp_network
    sleep 10
done
