#!/bin/bash
set -e

AGENT_LABEL="com.intune.corpnetwork"
AGENT_PLIST="$AGENT_LABEL.plist"
AGENT_DEST="/Library/LaunchAgents/$AGENT_PLIST"
SCRIPT_DIR="/Library/Application Support/corp-network-detector"
SCRIPT_PATH="$SCRIPT_DIR/corp_network_check.sh"
LOG_FILE="/Users/Shared/corp_network_check.log"

echo "🔄 Uninstalling Corp Network Detector..."

# Log uninstallation
echo "$(date): Starting uninstallation..." >> "$LOG_FILE"

# Get current user ID for proper user context
CURRENT_USER=$(stat -f "%Su" /dev/console)
USER_ID=$(id -u "$CURRENT_USER")

# Stop and unload agent if it exists (user context)
if sudo -u "$CURRENT_USER" launchctl list 2>/dev/null | grep -q "$AGENT_LABEL"; then
    echo "Stopping existing agent..."
    echo "$(date): Stopping agent" >> "$LOG_FILE"
    if sudo -u "$CURRENT_USER" launchctl bootout gui/$USER_ID/$AGENT_LABEL 2>&1 | tee -a "$LOG_FILE"; then
        echo "$(date): Agent unloaded successfully" >> "$LOG_FILE"
    else
        echo "$(date): Warning - Failed to unload agent" >> "$LOG_FILE"
    fi
fi

# Kill any remaining processes
pkill -f corp_network_check.sh 2>/dev/null || true

# Remove plist file
if [ -f "$AGENT_DEST" ]; then
    rm -f "$AGENT_DEST"
    echo "Removed LaunchAgent: $AGENT_DEST"
    echo "$(date): Removed LaunchAgent plist" >> "$LOG_FILE"
fi

# Remove script
if [ -f "$SCRIPT_PATH" ]; then
    rm -f "$SCRIPT_PATH"
    echo "Removed script: $SCRIPT_PATH"
    echo "$(date): Removed monitor script" >> "$LOG_FILE"
fi

# Remove script directory
if [ -d "$SCRIPT_DIR" ]; then
    rm -rf "$SCRIPT_DIR"
    echo "Removed script directory: $SCRIPT_DIR"
    echo "$(date): Removed script directory" >> "$LOG_FILE"
fi

echo "✅ Uninstallation complete."
echo "$(date): Uninstallation completed successfully" >> "$LOG_FILE"
echo "Logs available at: $LOG_FILE"