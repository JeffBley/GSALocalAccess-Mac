#!/bin/bash
set -e

AGENT_LABEL="com.intune.corpnetwork"
AGENT_PLIST="$AGENT_LABEL.plist"
AGENT_DEST="/Library/LaunchAgents/$AGENT_PLIST"
SCRIPT_DIR="/Library/Application Support/corp-network-detector"
SCRIPT_PATH="$SCRIPT_DIR/corp_network_check.sh"
LOG_FILE="/Users/Shared/corp_network_check.log"

echo "🔄 Installing Corp Network Detector..."

# Log installation
echo "$(date): Starting installation..." >> "$LOG_FILE"

# Verify files exist before loading
if [ ! -f "$AGENT_DEST" ]; then
    echo "❌ Error: $AGENT_DEST not found. Ensure package is installed correctly."
    echo "$(date): ERROR - $AGENT_DEST not found" >> "$LOG_FILE"
    exit 1
fi

if [ ! -f "$SCRIPT_PATH" ]; then
    echo "❌ Error: $SCRIPT_PATH not found. Ensure package is installed correctly."
    echo "$(date): ERROR - $SCRIPT_PATH not found" >> "$LOG_FILE"
    exit 1
fi

echo "$(date): Files verified successfully" >> "$LOG_FILE"

# Get current user ID for proper user context
CURRENT_USER=$(stat -f "%Su" /dev/console)
USER_ID=$(id -u "$CURRENT_USER")

# Stop and unload old agent if it exists (user context)
echo "Checking for existing agent..."
if sudo -u "$CURRENT_USER" launchctl list 2>/dev/null | grep -q "$AGENT_LABEL"; then
    echo "Stopping existing agent..."
    echo "$(date): Stopping existing agent" >> "$LOG_FILE"
    sudo -u "$CURRENT_USER" launchctl bootout gui/$USER_ID/$AGENT_LABEL 2>/dev/null || true
    sleep 2
fi

# Set proper permissions
echo "Setting permissions..."
echo "$(date): Setting permissions" >> "$LOG_FILE"
chmod 755 "$SCRIPT_PATH"
chmod 644 "$AGENT_DEST"
chown root:wheel "$AGENT_DEST"

# Ensure log file is writable by the user
touch "$LOG_FILE"
chown "$CURRENT_USER:staff" "$LOG_FILE"
chmod 644 "$LOG_FILE"

# Load new agent in user context (bootstrap automatically starts it)
echo "Loading LaunchAgent..."
echo "$(date): Loading LaunchAgent" >> "$LOG_FILE"
if sudo -u "$CURRENT_USER" launchctl bootstrap gui/$USER_ID "$AGENT_DEST" 2>&1; then
    echo "$(date): LaunchAgent loaded successfully" >> "$LOG_FILE"
    
    # Wait a moment for the agent to start
    sleep 2
    
    # Verify it's running
    if sudo -u "$CURRENT_USER" launchctl list 2>/dev/null | grep -q "$AGENT_LABEL"; then
        echo "✅ Installation complete - Agent is running"
        echo "$(date): Installation completed successfully - Agent verified running" >> "$LOG_FILE"
    else
        echo "⚠️  Installation complete but agent may not be running"
        echo "$(date): Installation completed but agent not detected in launchctl list" >> "$LOG_FILE"
    fi
else
    echo "❌ Error: Failed to load LaunchAgent"
    echo "$(date): ERROR - Failed to load LaunchAgent" >> "$LOG_FILE"
    exit 1
fi

echo "Logs available at: $LOG_FILE"
echo ""
echo "⚠️  IMPORTANT: Ensure /bin/bash has Full Disk Access in System Settings > Privacy & Security"