# Corp Network Detector

A macOS LaunchAgent that automatically detects corporate network presence and toggles Microsoft Global Secure Access private access settings accordingly.

## Overview

This solution monitors network connectivity changes by checking network signatures (interface, SSID, and IP address) every 15 seconds. When a network change is detected, it performs a DNS resolution check to determine corporate network presence. Based on the results, it automatically enables or disables Microsoft Global Secure Access private access, ensuring users have the optimal configuration whether they're on or off the corporate network.

## Features

- **Intelligent Network Detection**: Monitors network signature changes (interface + SSID + IP) every 15 seconds
- **Efficient Resource Usage**: Only performs DNS checks when the network actually changes
- **Smart Preference Management**: Reads current preference value and only updates if needed
- **Verification System**: Confirms preference changes were applied successfully
- **Robust Error Handling**: DNS queries include timeouts and retry logic to prevent false positives
- **Automatic Log Rotation**: All logs limited to 10,000 lines with automatic rotation
- **Production Ready**: Comprehensive logging, validation, and diagnostics included
- **Status Monitoring**: Built-in status check script for easy troubleshooting

## Components

### Core Files

- **`corp_network_check.sh`**: Main monitoring script that performs DNS checks and toggles settings
- **`com.intune.corpnetwork.plist`**: LaunchAgent configuration for macOS service management
- **`install.sh`**: Installation script that loads and starts the LaunchAgent
- **`uninstall.sh`**: Uninstallation script that removes all components
- **`status.sh`**: Diagnostic script to check service health and current status

## Prerequisites

### Required

- macOS 10.14 or later
- Root/administrator privileges
- Microsoft Global Secure Access client installed
- **Full Disk Access for /bin/bash** (Critical - see installation steps)

### Package Requirements

Package installer (.pkg) that places files in the following locations:
- `/Library/LaunchAgents/com.intune.corpnetwork.plist`
- `/Library/Application Support/corp-network-detector/corp_network_check.sh`

## Installation

### Step 1: Grant Full Disk Access

**This step is REQUIRED before installation:**

1. Open **System Settings** (or System Preferences on older macOS)
2. Go to **Privacy & Security** > **Full Disk Access**
3. Click the **🔒 lock icon** and authenticate
4. Click the **+** button
5. Press **Command + Shift + G** to open "Go to folder"
6. Type: `/bin/bash` and press Enter
7. Click **Open**
8. **Enable the toggle** for bash

**Why is this required?** Microsoft Global Secure Access stores preferences in a sandboxed container. Without Full Disk Access, the script cannot modify these preferences.

### Step 2: Deploy Files

**Via Package Installer:**

1. **Package the files** into a .pkg installer that places:
   - Plist file at `/Library/LaunchAgents/com.intune.corpnetwork.plist`
   - Shell script at `/Library/Application Support/corp-network-detector/corp_network_check.sh`

2. **Include install.sh as a postinstall script** in your .pkg

3. **Deploy via Intune** or other MDM solution

**Manual Installation (for testing):**

```bash
# 1. Copy the plist to LaunchAgents
sudo cp com.intune.corpnetwork.plist /Library/LaunchAgents/

# 2. Create the script directory and copy the monitoring script
sudo mkdir -p "/Library/Application Support/corp-network-detector"
sudo cp corp_network_check.sh "/Library/Application Support/corp-network-detector/"

# 3. Make the monitoring script executable
sudo chmod +x "/Library/Application Support/corp-network-detector/corp_network_check.sh"

# 4. Run the install script
sudo bash install.sh
```

## Configuration

### DNS Domain

The corporate domain being monitored is defined in `corp_network_check.sh`:

```bash
CORP_DOMAIN="private.edgediagnostic.globalseecureaccess.microsoft.com"
```

To change the monitored domain, update this variable before deployment.

### Network Monitoring Method

The script monitors network changes by checking the network signature every 15 seconds:

**Network Signature Components:**
- Primary network interface (e.g., en0, en1)
- WiFi SSID (if connected to WiFi)
- IP address

**How it works:**
1. Every 15 seconds, the script checks the current network signature
2. If the signature has changed (different network, different IP, etc.), it triggers a DNS check
3. DNS check determines if on corporate network
4. Preference is checked and updated only if needed
5. Change is verified and logged

**Benefits of this approach:**
- Fast response time (15 seconds maximum delay)
- Efficient (no DNS checks when network is stable)
- Reliable (doesn't depend on system notifications)
- Simple (easy to understand and debug)

### Check Behavior

- **On startup**: Runs one initial check to set correct state
- **Every 15 seconds**: Checks network signature for changes
- **On network change**: Performs DNS check when signature changes (WiFi connect/disconnect, Ethernet plug/unplug, VPN connect/disconnect, IP change, etc.)
- **Preference verification**: Reads current value before writing, only updates if different
- **Error handling**: DNS failures are logged but don't change the last known state

### Microsoft Global Secure Access Setting

The script toggles the following preference:

```bash
com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser
```

- **Value 0**: Private access enabled (user is OFF corporate network)
- **Value 1**: Private access disabled (user is ON corporate network)

## Monitoring & Diagnostics

### Check Service Status

Run the status script to see comprehensive diagnostics:

```bash
sudo bash status.sh
```

This displays:
- File existence and locations
- Service running status and PID
- Current network detection state
- Microsoft Global Secure Access setting value
- Full Disk Access status
- Last 10 log entries

### View Logs

**Monitor logs** (network checks):
```bash
# View entire log
cat /Users/Shared/corp_network_check.log

# View last 20 entries
tail -20 /Users/Shared/corp_network_check.log

# Follow logs in real-time
tail -f /Users/Shared/corp_network_check.log
```

**Stdout/Stderr logs** (script output and errors):
```bash
# View stdout
cat /Users/Shared/corp_network_check_stdout.log

# View stderr
cat /Users/Shared/corp_network_check_stderr.log
```

### Check LaunchAgent Status

```bash
# Get current user
CURRENT_USER=$(stat -f "%Su" /dev/console)

# Check if agent is loaded
sudo -u "$CURRENT_USER" launchctl list | grep com.intune.corpnetwork

# View detailed agent info
sudo -u "$CURRENT_USER" launchctl print gui/$(id -u "$CURRENT_USER")/com.intune.corpnetwork
```

## Uninstallation

To remove the Corp Network Detector:

```bash
sudo bash uninstall.sh
```

This removes:
- LaunchAgent from system
- All script files
- Script directory

**Note**: Log files in `/Users/Shared/` are preserved for audit purposes.

## Log Management

The solution uses intelligent log management with automatic rotation:

- **Maximum entries per log**: 10,000 lines
- **Rotation method**: Oldest entries automatically removed when limit reached
- **No external tools required**: Built-in log management prevents disk space issues

**Log Rotation Schedule:**
- `corp_network_check.log` - Rotates immediately when exceeding 10,000 lines
- `corp_network_check_stdout.log` - Rotates every hour if exceeding 10,000 lines
- `corp_network_check_stderr.log` - Rotates every hour if exceeding 10,000 lines

**What gets logged:**
- Network signature changes (interface/SSID/IP changes)
- DNS resolution results (inside/outside corp network)
- Preference updates (when value needs to change)
- Preference verification (confirms value is correct)
- Errors and warnings
- Log rotation events

## Troubleshooting

### Agent Not Running (Exit Code 78)

If `launchctl list` shows exit code 78:

1. **Check Full Disk Access**:
   ```bash
   sudo bash status.sh
   ```
   Look for the "🔐 Full Disk Access Status" section

2. **Manually run the script to see errors**:
   ```bash
   CURRENT_USER=$(stat -f "%Su" /dev/console)
   sudo -u "$CURRENT_USER" /bin/bash "/Library/Application Support/corp-network-detector/corp_network_check.sh"
   ```

3. **Check stderr logs**:
   ```bash
   cat /Users/Shared/corp_network_check_stderr.log
   ```

4. **Check system logs**:
   ```bash
   log show --predicate 'process == "launchd"' --last 10m | grep corpnetwork
   ```

### Agent Not Loading

1. Check if files exist:
   ```bash
   ls -la /Library/LaunchAgents/com.intune.corpnetwork.plist
   ls -la "/Library/Application Support/corp-network-detector/corp_network_check.sh"
   ```

2. Check permissions:
   ```bash
   # Plist should be 644, owned by root:wheel
   # Script should be 755
   ```

3. Validate plist syntax:
   ```bash
   plutil -lint /Library/LaunchAgents/com.intune.corpnetwork.plist
   ```

4. Try manually loading:
   ```bash
   CURRENT_USER=$(stat -f "%Su" /dev/console)
   USER_ID=$(id -u "$CURRENT_USER")
   sudo -u "$CURRENT_USER" launchctl bootstrap gui/$USER_ID /Library/LaunchAgents/com.intune.corpnetwork.plist
   ```

### Network Detection Not Working

1. Test DNS resolution manually:
   ```bash
   dig +short +time=5 +tries=2 private.edgediagnostic.globalseecureaccess.microsoft.com
   ```

2. Check if the domain is accessible from your corporate network

3. Verify Microsoft Global Secure Access client is installed

4. Check current preference value:
   ```bash
   defaults read com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser
   ```

### Preferences Not Changing

1. **Verify Full Disk Access is granted** (most common issue)
2. Check if Microsoft Global Secure Access is running
3. Try manually setting the preference:
   ```bash
   defaults write com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser -int 0
   defaults read com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser
   ```

### Installation Failed

1. Check installation log:
   ```bash
   tail -20 /Users/Shared/corp_network_check.log | grep installation
   ```

2. Verify all files were installed by the .pkg

3. Ensure running with root privileges

## File Locations

| File | Location |
|------|----------|
| LaunchAgent plist | `/Library/LaunchAgents/com.intune.corpnetwork.plist` |
| Monitor script | `/Library/Application Support/corp-network-detector/corp_network_check.sh` |
| Monitor logs | `/Users/Shared/corp_network_check.log` |
| Script stdout | `/Users/Shared/corp_network_check_stdout.log` |
| Script stderr | `/Users/Shared/corp_network_check_stderr.log` |

## Technical Details

### DNS Query Behavior

- **Timeout**: 5 seconds per query
- **Retries**: 2 attempts
- **Error handling**: DNS failures logged as warnings, settings unchanged

### Service Lifecycle

1. Package installer places files
2. Postinstall script (`install.sh`) validates files, sets permissions, and loads agent
3. LaunchAgent starts `corp_network_check.sh` in user context (not root)
4. Script performs initial network check and gets baseline network signature
5. Script checks network signature every 15 seconds
6. When signature changes, DNS check runs and preferences are updated if needed
7. Logs rotate automatically when they reach 10,000 lines
8. On uninstall, agent is stopped and all files removed

### User Context

The LaunchAgent runs in the logged-in user's context (not as root) using:
- `LimitLoadToSessionType = Aqua` in the plist
- `launchctl bootstrap gui/$USER_ID` during installation

This is required because:
- User preferences are per-user, not system-wide
- Microsoft Global Secure Access runs in user space
- Full Disk Access applies to the user running the script

### Log Format

```
[timestamp]: [status] [message]
```

Example entries:
```
Fri Oct 24 10:30:15 EDT 2025: Initial network check on startup...
Fri Oct 24 10:30:15 EDT 2025: ✅ Inside corp network (resolved 10.0.0.1)
Fri Oct 24 10:30:15 EDT 2025: ✓ IsPrivateAccessDisabledByUser already set to correct value (1)
Fri Oct 24 10:30:15 EDT 2025: ✓ Verified preference value is correct: 1
Fri Oct 24 10:30:15 EDT 2025: Monitoring for network changes (checking every 15s)...
Fri Oct 24 12:45:22 EDT 2025: Network change detected (en0:CorpWiFi:10.0.0.1 → en1:HomeWiFi:192.168.1.100)
Fri Oct 24 12:45:22 EDT 2025: ❌ Outside corp network (failed to resolve private.edgediagnostic.globalseecureaccess.microsoft.com)
Fri Oct 24 12:45:22 EDT 2025: ⚙️  Updated IsPrivateAccessDisabledByUser from 1 to 0
Fri Oct 24 12:45:22 EDT 2025: ✓ Verified preference value is correct: 0
Fri Oct 24 14:20:10 EDT 2025: Network change detected (en1:HomeWiFi:192.168.1.100 → en0:CorpWiFi:10.0.0.1)
Fri Oct 24 14:20:10 EDT 2025: ✅ Inside corp network (resolved 10.0.0.1)
Fri Oct 24 14:20:10 EDT 2025: ⚙️  Updated IsPrivateAccessDisabledByUser from 0 to 1
Fri Oct 24 14:20:10 EDT 2025: ✓ Verified preference value is correct: 1
```

## Security Considerations

- Runs as logged-in user (not root) for security
- All files owned by root:wheel to prevent tampering
- Plist file set to 644 (read-only for non-root)
- Script file set to 755 (executable, but not writable by non-root)
- No network connections other than DNS queries
- No sensitive data stored or transmitted
- Requires Full Disk Access (user must explicitly grant permission)

## macOS Compatibility

- **Minimum**: macOS 10.14 (Mojave)
- **Tested**: macOS 11.0+ (Big Sur and later)
- **launchctl syntax**: Uses modern `bootstrap/bootout` commands (macOS 10.11+)

For older macOS versions, the install/uninstall scripts may need modification to use legacy `load/unload` commands.

## Support

For issues or questions:
1. Run `status.sh` to gather diagnostic information
2. Check logs in `/Users/Shared/`
3. Verify Microsoft Global Secure Access client is functioning properly
4. Ensure Full Disk Access is granted to `/bin/bash`

## Known Limitations

- Requires Full Disk Access for `/bin/bash` (user must grant manually)
- Only monitors one DNS domain at a time
- Network changes detected within 15 seconds (polling interval)
- Very rapid network changes within the same 15-second window may be coalesced
- Sandboxed apps require special handling (Full Disk Access)
- Log files limited to 10,000 lines each (oldest entries are automatically removed)

## License

Internal corporate use - modify as needed for your organization.

## Version History

- **v1.0** - Initial release with timer-based polling (10-second intervals) and log rotation
- **v1.1** - Fixed user context issues, added Full Disk Access requirement, modernized launchctl commands
- **v2.0** - Changed to network signature monitoring (15-second checks), added preference verification, improved log management with 10K line limits

## Configuration

### DNS Domain

The corporate domain being monitored is defined in `corp_network_check.sh`:

```bash
CORP_DOMAIN="private.edgediagnostic.globalseecureaccess.microsoft.com"
```

To change the monitored domain, update this variable before deployment.

### Check Interval

The script checks network status every 10 seconds. To modify:

```bash
sleep 10  # Change this value in corp_network_check.sh
```

**Note**: If you change the interval, also update `MAX_LOG_LINES` calculation to maintain 3 days of logs:
- Current: 25,920 lines = 3 days × 24 hours × 360 checks/hour (10 second interval)
- Formula: `MAX_LOG_LINES = (3 × 24 × 3600) / INTERVAL_IN_SECONDS`

### Microsoft Global Secure Access Setting

The script toggles the following preference:

```bash
com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser
```

- **Value 0**: Private access enabled (user is OFF corporate network)
- **Value 1**: Private access disabled (user is ON corporate network)

## Monitoring & Diagnostics

### Check Service Status

Run the status script to see comprehensive diagnostics:

```bash
sudo bash status.sh
```

This displays:
- File existence and locations
- Service running status and PID
- Current network detection state
- Microsoft Global Secure Access setting value
- Last 10 log entries

### View Logs

**Monitor logs** (network checks):
```bash
tail -f /Library/Logs/Microsoft/globalsecureaccessclient/corp_network_check.log
```

**Installation logs**:
```bash
cat /Library/Logs/Microsoft/globalsecureaccessclient/installation.log
```

### Check LaunchAgent Status

```bash
# Check if agent is loaded
launchctl list | grep com.intune.corpnetwork

# View agent details
launchctl print gui/$(id -u)/com.intune.corpnetwork
```

## Uninstallation

To remove the Corp Network Detector:

```bash
sudo bash uninstall.sh
```

This removes:
- LaunchAgent from system
- All script files
- Script directory

**Note**: Log files are preserved for audit purposes.

## Log Management

The solution includes automatic log rotation:

- **Maximum entries**: 25,920 (3 days at 10-second intervals)
- **Rotation method**: Oldest entries automatically removed when limit reached
- **No external tools required**: Built-in log management prevents disk space issues

## Troubleshooting

### Agent Not Running

1. Check if files exist:
   ```bash
   ls -la /Library/LaunchAgents/com.intune.corpnetwork.plist
   ls -la "/Library/Application Support/corp-network-detector/corp_network_check.sh"
   ```

2. Check permissions:
   ```bash
   # Plist should be 644, owned by root:wheel
   # Script should be 755
   ```

3. Try manually loading:
   ```bash
   sudo launchctl load /Library/LaunchAgents/com.intune.corpnetwork.plist
   sudo launchctl start com.intune.corpnetwork
   ```

4. Check system logs:
   ```bash
   log show --predicate 'process == "corp_network_check.sh"' --last 5m
   ```

### Network Detection Not Working

1. Test DNS resolution manually:
   ```bash
   dig +short +time=5 +tries=2 private.edgediagnostic.globalseecureaccess.microsoft.com
   ```

2. Check if the domain is accessible from your corporate network

3. Verify Microsoft Global Secure Access client is installed

4. Check current preference value:
   ```bash
   defaults read com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser
   ```

### Installation Failed

1. Check installation log:
   ```bash
   cat /Library/Logs/Microsoft/globalsecureaccessclient/installation.log
   ```

2. Verify all files were installed by the .pkg

3. Ensure running with root privileges

## File Locations

| File | Location |
|------|----------|
| LaunchAgent plist | `/Library/LaunchAgents/com.intune.corpnetwork.plist` |
| Monitor script | `/Library/Application Support/corp-network-detector/corp_network_check.sh` |
| Monitor logs | `/Library/Logs/Microsoft/globalsecureaccessclient/corp_network_check.log` |
| Installation logs | `/Library/Logs/Microsoft/globalsecureaccessclient/installation.log` |

## Technical Details

### DNS Query Behavior

- **Timeout**: 5 seconds per query
- **Retries**: 2 attempts
- **Error handling**: DNS failures logged as warnings, settings unchanged

### Service Lifecycle

1. Package installer places files
2. Postinstall script (`install.sh`) validates files and loads agent
3. LaunchAgent starts `corp_network_check.sh` at boot and keeps it running
4. Script runs in infinite loop, checking every 10 seconds
5. On uninstall, agent is stopped and all files removed

### Log Format

```
[timestamp]: [status] [message]
```

Example entries:
```
Fri Oct 24 10:30:15 EDT 2025: ✅ Inside corp network (resolved 10.0.0.1)
Fri Oct 24 10:30:25 EDT 2025: ❌ Outside corp network (failed to resolve private.edgediagnostic.globalseecureaccess.microsoft.com)
Fri Oct 24 10:30:35 EDT 2025: ⚠️  DNS query failed: connection timed out
```

## Security Considerations

- Runs as root (required for LaunchAgent and system preferences)
- All files owned by root:wheel
- Plist file set to 644 (read-only for non-root)
- Script file set to 755 (executable, but not writable by non-root)
- No network connections other than DNS queries
- No sensitive data stored or transmitted

## Support

For issues or questions:
1. Run `status.sh` to gather diagnostic information
2. Check logs in `/Library/Logs/Microsoft/globalsecureaccessclient/`
3. Verify Microsoft Global Secure Access client is functioning properly

## License

Internal corporate use - modify as needed for your organization.

## Version History

- **v1.0** - Initial release with automatic network detection and log rotation