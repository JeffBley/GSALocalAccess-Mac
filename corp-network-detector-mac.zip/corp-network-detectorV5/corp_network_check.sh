#!/bin/bash

CORP_DOMAIN="private.edgediagnostic.globalseecureaccess.microsoft.com"
LOG_FILE="/Users/Shared/corp_network_check.log"
STATE_FILE="/tmp/corp_network_last_state"
CHECK_INTERVAL=15  # Check every 15 seconds when network is stable
MAX_LOG_LINES=10000  # Maximum number of log entries to keep
ROTATION_COUNTER=0  # Counter for periodic log rotation
ROTATION_INTERVAL=240  # Rotate stdout/stderr logs every 240 checks (1 hour at 15s intervals)

echo "Starting corp network check (network change monitoring mode)..."
echo "Logging to $LOG_FILE"

# Ensure log directory exists (Users/Shared should always exist, but being safe)
if [ ! -d "/Users/Shared" ]; then
    mkdir -p "/Users/Shared" 2>/dev/null || echo "Warning: Could not create /Users/Shared"
fi

check_corp_network() {
    local log_message=""
    local dig_output=""
    local new_state=""
    local expected_value=""
    
    # Attempt DNS resolution with timeout and retry limits
    if dig_output=$(dig +short +time=5 +tries=2 "$CORP_DOMAIN" 2>&1); then
        if [ -z "$dig_output" ]; then
            log_message="$(date): ❌ Outside corp network (failed to resolve $CORP_DOMAIN)"
            new_state="outside"
            expected_value=0
        else
            log_message="$(date): ✅ Inside corp network (resolved $CORP_DOMAIN to $dig_output)"
            new_state="inside"
            expected_value=1
        fi
    else
        # DNS query failed (timeout, network error, etc.)
        log_message="$(date): ⚠️  DNS query failed: $dig_output"
        new_state="error"
        # Don't change the defaults write state on errors
    fi
    
    # Always log the result
    echo "$log_message" >> "$LOG_FILE"
    
    # If we determined an expected value (not error), check and set if needed
    if [ "$new_state" != "error" ]; then
        # Get current preference value
        local current_value=$(defaults read com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 2>/dev/null)
        
        if [ "$current_value" != "$expected_value" ]; then
            # Value is incorrect, update it
            defaults write com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser -int "$expected_value" 2>/dev/null
            echo "$(date): ⚙️  Updated IsPrivateAccessDisabledByUser from $current_value to $expected_value" >> "$LOG_FILE"
        else
            # Value is already correct
            echo "$(date): ✓ IsPrivateAccessDisabledByUser already set to correct value ($expected_value)" >> "$LOG_FILE"
        fi
        
        # Save new state
        echo "$new_state" > "$STATE_FILE"
        
        # Verify the preference was written correctly
        local verified_value=$(defaults read com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 2>/dev/null)
        if [ "$verified_value" = "$expected_value" ]; then
            echo "$(date): ✓ Verified preference value is correct: $verified_value" >> "$LOG_FILE"
        else
            echo "$(date): ⚠️  Warning: Preference verification failed - expected $expected_value but got $verified_value" >> "$LOG_FILE"
        fi
    fi
    
    # Rotate log file if it exceeds maximum lines
    if [ -f "$LOG_FILE" ]; then
        local line_count=$(wc -l < "$LOG_FILE" 2>/dev/null || echo "0")
        if [ "$line_count" -gt "$MAX_LOG_LINES" ]; then
            # Keep only the most recent MAX_LOG_LINES entries
            tail -n "$MAX_LOG_LINES" "$LOG_FILE" > "$LOG_FILE.tmp" 2>/dev/null && mv "$LOG_FILE.tmp" "$LOG_FILE" 2>/dev/null
            echo "$(date): 📋 Rotated log file (was $line_count lines, now $MAX_LOG_LINES)" >> "$LOG_FILE"
        fi
    fi
}

# Get current primary network interface
get_primary_interface() {
    route -n get default 2>/dev/null | grep interface | awk '{print $2}'
}

# Get current network signature (SSID + IP)
get_network_signature() {
    local interface=$(get_primary_interface)
    local ssid=""
    local ip=""
    
    # Get SSID if on WiFi
    if [ -n "$interface" ]; then
        ssid=$(networksetup -getairportnetwork "$interface" 2>/dev/null | awk -F': ' '{print $2}')
        ip=$(ipconfig getifaddr "$interface" 2>/dev/null)
    fi
    
    echo "${interface}:${ssid}:${ip}"
}

# Rotate stdout/stderr logs
rotate_other_logs() {
    local stdout_log="/Users/Shared/corp_network_check_stdout.log"
    local stderr_log="/Users/Shared/corp_network_check_stderr.log"
    
    for log in "$stdout_log" "$stderr_log"; do
        if [ -f "$log" ]; then
            local line_count=$(wc -l < "$log" 2>/dev/null || echo "0")
            if [ "$line_count" -gt "$MAX_LOG_LINES" ]; then
                tail -n "$MAX_LOG_LINES" "$log" > "$log.tmp" 2>/dev/null && mv "$log.tmp" "$log" 2>/dev/null
            fi
        fi
    done
}

# Run initial check
echo "$(date): Initial network check on startup..." >> "$LOG_FILE"
check_corp_network
last_signature=$(get_network_signature)

echo "$(date): Monitoring for network changes (checking every ${CHECK_INTERVAL}s)..." >> "$LOG_FILE"

# Monitor loop - check periodically and detect changes
while true; do
    sleep "$CHECK_INTERVAL"
    
    # Increment rotation counter and rotate other logs if needed
    ROTATION_COUNTER=$((ROTATION_COUNTER + 1))
    if [ "$ROTATION_COUNTER" -ge "$ROTATION_INTERVAL" ]; then
        rotate_other_logs
        ROTATION_COUNTER=0
    fi
    
    current_signature=$(get_network_signature)
    
    # Only check DNS if network signature changed
    if [ "$current_signature" != "$last_signature" ]; then
        echo "$(date): Network change detected (${last_signature} → ${current_signature})" >> "$LOG_FILE"
        check_corp_network
        last_signature="$current_signature"
    fi
done