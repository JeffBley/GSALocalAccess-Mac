#!/bin/bash

AGENT_LABEL="com.intune.corpnetwork"
AGENT_PLIST="$AGENT_LABEL.plist"
AGENT_DEST="/Library/LaunchAgents/$AGENT_PLIST"
SCRIPT_DIR="/Library/Application Support/corp-network-detector"
SCRIPT_PATH="$SCRIPT_DIR/corp_network_check.sh"
LOG_FILE="/Users/Shared/corp_network_check.log"
CORP_DOMAIN="private.edgediagnostic.globalseecureaccess.microsoft.com"

# Get current user for proper context
CURRENT_USER=$(stat -f "%Su" /dev/console)

echo "======================================"
echo "Corp Network Detector - Status Check"
echo "======================================"
echo ""

# Check if files exist
echo "📁 File Status:"
if [ -f "$AGENT_DEST" ]; then
    echo "  ✅ LaunchAgent plist: $AGENT_DEST"
else
    echo "  ❌ LaunchAgent plist: NOT FOUND"
fi

if [ -f "$SCRIPT_PATH" ]; then
    echo "  ✅ Monitor script: $SCRIPT_PATH"
else
    echo "  ❌ Monitor script: NOT FOUND"
fi

if [ -f "$LOG_FILE" ]; then
    echo "  ✅ Log file: $LOG_FILE"
else
    echo "  ❌ Log file: NOT FOUND"
fi

echo ""

# Check if agent is loaded and running
echo "🔧 Service Status:"
if sudo -u "$CURRENT_USER" launchctl list 2>/dev/null | grep -q "$AGENT_LABEL"; then
    echo "  ✅ Agent is loaded and running"
    
    # Get PID
    PID=$(sudo -u "$CURRENT_USER" launchctl list 2>/dev/null | grep "$AGENT_LABEL" | awk '{print $1}')
    if [ "$PID" != "-" ] && [ -n "$PID" ]; then
        echo "  📊 Process ID: $PID"
    fi
else
    echo "  ❌ Agent is NOT running"
fi

echo ""

# Check current network status
echo "🌐 Current Network Status:"
if dig_output=$(dig +short +time=5 +tries=2 "$CORP_DOMAIN" 2>&1); then
    if [ -z "$dig_output" ]; then
        echo "  ❌ Outside corp network (cannot resolve $CORP_DOMAIN)"
    else
        echo "  ✅ Inside corp network (resolved: $dig_output)"
    fi
else
    echo "  ⚠️  DNS query failed: $dig_output"
fi

echo ""

# Check Microsoft Global Secure Access setting
echo "⚙️  Microsoft Global Secure Access Setting:"
PREF_VALUE=$(defaults read com.microsoft.globalsecureaccess IsPrivateAccessDisabledByUser 2>/dev/null)
if [ $? -eq 0 ]; then
    if [ "$PREF_VALUE" = "1" ]; then
        echo "  📍 IsPrivateAccessDisabledByUser: 1 (Disabled - on corp network)"
    elif [ "$PREF_VALUE" = "0" ]; then
        echo "  📍 IsPrivateAccessDisabledByUser: 0 (Enabled - off corp network)"
    else
        echo "  ⚠️  IsPrivateAccessDisabledByUser: $PREF_VALUE (Unexpected value)"
    fi
else
    echo "  ❌ Setting not found (preference domain may not exist)"
fi

echo ""

# Check Full Disk Access
echo "🔐 Full Disk Access Status:"
BASH_FDA=$(sqlite3 "/Library/Application Support/com.apple.TCC/TCC.db" "SELECT allowed FROM access WHERE service='kTCCServiceSystemPolicyAllFiles' AND client='/bin/bash';" 2>/dev/null || echo "unknown")
if [ "$BASH_FDA" = "1" ]; then
    echo "  ✅ /bin/bash has Full Disk Access"
elif [ "$BASH_FDA" = "0" ]; then
    echo "  ❌ /bin/bash does NOT have Full Disk Access (REQUIRED)"
    echo "     Enable in: System Settings > Privacy & Security > Full Disk Access"
else
    echo "  ⚠️  Could not determine Full Disk Access status"
    echo "     Verify in: System Settings > Privacy & Security > Full Disk Access"
fi

echo ""

# Show recent log entries
echo "📋 Recent Log Entries (last 10):"
if [ -f "$LOG_FILE" ]; then
    tail -n 10 "$LOG_FILE" | sed 's/^/  /'
else
    echo "  ❌ No log file found"
fi

echo ""
echo "======================================"